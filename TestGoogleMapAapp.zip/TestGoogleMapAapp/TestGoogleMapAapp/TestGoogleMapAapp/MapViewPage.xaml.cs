﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TestGoogleMapAapp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.GoogleMaps;
using Xamarin.Forms.Xaml;

namespace TestGoogleMapAapp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MapViewPage : ContentPage
    {
        MapPageViewModel mapPageVM;
        public MapViewPage()
        {
            InitializeComponent();
            BindingContext = mapPageVM =  new MapPageViewModel();

           // Pin pinlocation = new Pin()
           // {
           //     Type = PinType.Place,
           //     Label = "India",
           //     Address = "Bhopal",
           //     Position = new Position(23.25d, 77.41d),
           //     Rotation= 33.3f,
           //     Tag = "Id_India"
           // };
           // map.Pins.Add(pinlocation);
           // map.MoveToRegion(MapSpan.FromCenterAndRadius(pinlocation.Position, Distance.FromMeters(1000)));
            ApplyMapTheam();
        }
        /// <summary>
        /// Allpying the Theam for map and show night vision map 
        /// Follow the link https://www.youtube.com/watch?v=OV1ChSc0S4Q
        /// </summary>
        private void ApplyMapTheam()
        {
            var assembly = typeof(MapViewPage).GetTypeInfo().Assembly;
            var stream = assembly.GetManifestResourceStream($"TestGoogleMapAapp.MapResources.MapTheam.json");
            string theamFile;
            using (var reader = new System.IO.StreamReader(stream))
            {
                theamFile = reader.ReadToEnd();
                map.MapStyle = MapStyle.FromJson(theamFile);
            }
        }

        private async void Button_Clicked(object sender, EventArgs e)
        {
            try
            {
                var contents = await mapPageVM.LoadVehicles();
                if (contents != null)
                {
                    foreach (var data in contents)
                    {
                        Pin VehiclePins = new Pin()
                        {
                            Label = "Cars",
                            Type = PinType.Place,
                             Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromBundle("carpinsm.png") : BitmapDescriptorFactory.FromView(new Image() { Source = "carpinsm.png", WidthRequest = 30, HeightRequest = 35 }),
                            //Icon = "carpinsm.png",
                            //   Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromView("carpinsm.png") : ImageSource.FromFile("Images/waterfront.jpg"),
                            Position = new Position(data.Lattitude, data.Longitude),
                        };
                         map.Pins.Add(VehiclePins);
                    }
                }
                    var position = new Position(23.216317, 77.433836);
                    map.MoveToRegion(MapSpan.FromCenterAndRadius(position, Distance.FromMeters(5000)));
            }
            catch (Exception ex)
            {

            }
        }
    }
}