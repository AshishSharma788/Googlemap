﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms.Internals;

namespace TestGoogleMapAapp.ViewModels
{
   public class MapPageViewModel
    {
        public class VehicleLocation
        {
            public double Lattitude { get; set; }
            public double Longitude { get; set; }
        }
        internal async Task<List<VehicleLocation>> LoadVehicles()
        {
            //call the api to get the vehicles nearby
            // list os location vehical
            List<VehicleLocation> vehicalLocations = new List<VehicleLocation>
            {
                new VehicleLocation {Lattitude = 23.211592, Longitude = 77.427758},
                new VehicleLocation {Lattitude = 23.213514, Longitude = 77.426320},
                new VehicleLocation {Lattitude = 23.213140, Longitude = 77.428648},
                new VehicleLocation {Lattitude = 23.212341, Longitude = 77.428519},
                new VehicleLocation {Lattitude = 23.211533, Longitude = 77.431191},
            };
            return vehicalLocations;
        }

    }
}
