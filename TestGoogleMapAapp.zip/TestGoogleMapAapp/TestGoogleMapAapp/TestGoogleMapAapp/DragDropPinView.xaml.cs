﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestGoogleMapAapp.ViewModels;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.GoogleMaps;
using Xamarin.Forms.Xaml;

namespace TestGoogleMapAapp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DragDropPinView : ContentPage
    {
        MapPageViewModel MapPageVM;
        public DragDropPinView()
        {
            InitializeComponent();
            BindingContext = MapPageVM = new MapPageViewModel();
        }

        private void map_PinDragEnd(object sender, Xamarin.Forms.GoogleMaps.PinDragEventArgs e)
        {

        }

        private async void map_PinDragStart(object sender, Xamarin.Forms.GoogleMaps.PinDragEventArgs e)
        {
            var position = new Position(e.Pin.Position.Latitude, e.Pin.Position.Longitude);
            map.MoveToRegion(MapSpan.FromCenterAndRadius(position, Distance.FromMeters(5000)));
            await App.Current.MainPage.DisplayAlert("Alert", "Pickup Pin location : Latitude" + position.Latitude + " Longitude " + position.Longitude,"ok");
        }

        private async void PickupLocation_Clicked(object sender, EventArgs e)
        {
            try
            {
                var location = await Geolocation.GetLocationAsync();
                if (location != null)
                {
                    Pin pinlocation = new Pin()
                    {
                        Type = PinType.Place,
                        Label = "India",
                        Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromBundle("mappin.png") : BitmapDescriptorFactory.FromView(new Image() { Source = "mappin.png", WidthRequest = 30, HeightRequest = 35 }),
                        //Icon = "carpinsm.png",
                        //   Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromView("carpinsm.png") : ImageSource.FromFile("Images/waterfront.jpg"),
                        Position = new Position(location.Latitude, location.Longitude),
                        IsDraggable = true
                    };
                    map.Pins.Add(pinlocation);
                    var position = new Position(23.216317, 77.433836);
                    map.MoveToRegion(MapSpan.FromCenterAndRadius(position, Distance.FromMeters(5000)));


                   
                   // lblAlt.Text += location.Altitude.ToString();
                }
            }
            catch (FeatureNotSupportedException fnsEx)
            {
                // Handle not supported on device exception  
            }
            catch (PermissionException pEx)
            {
                // Handle permission exception  
            }
            catch (Exception ex)
            {
                // Unable to get location  
            }
           
        }
    }
}