﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestGoogleMapAapp.Constants
{
   public class AppConstants
    {
        public const string GoogleMapsApiKey = "AIzaSyD6_vp1TqvO7MQ6je9vJgzLzcn7ScJRFqE";
    }
}
