﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TestGoogleMapAapp.ViewModels;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.GoogleMaps;
using Xamarin.Forms.Xaml;

namespace TestGoogleMapAapp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MovingCarView : ContentPage
    {
        MapPageViewModel mapPageVM;
        public MovingCarView()
        {
            InitializeComponent();
            BindingContext = mapPageVM = new MapPageViewModel();
            ApplyMapTheam();
        }
        /// <summary>
        /// Allpying the Theam for map and show night vision map 
        /// Follow the link https://www.youtube.com/watch?v=OV1ChSc0S4Q
        /// </summary>
        private void ApplyMapTheam()
        {
            var assembly = typeof(MapViewPage).GetTypeInfo().Assembly;
            var stream = assembly.GetManifestResourceStream($"TestGoogleMapAapp.MapResources.MapTheam.json");
            string theamFile;
            using (var reader = new System.IO.StreamReader(stream))
            {
                theamFile = reader.ReadToEnd();
                map.MapStyle = MapStyle.FromJson(theamFile);
            }
        }

        private async void LoadVehicle_Clicked(object sender, EventArgs e)
        {
            try
            {
                var contents = await mapPageVM.LoadVehicles();
                if (contents != null)
                {
                    foreach (var data in contents)
                    {
                        Pin VehiclePins = new Pin()
                        {
                            Label = "Cars",
                            Type = PinType.Place,
                            Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromBundle("carpinsm.png") : BitmapDescriptorFactory.FromView(new Image() { Source = "carpinsm.png", WidthRequest = 30, HeightRequest = 35 }),
                            //Icon = "carpinsm.png",
                            //   Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromView("carpinsm.png") : ImageSource.FromFile("Images/waterfront.jpg"),
                            Position = new Position(data.Lattitude, data.Longitude),
                        };
                        map.Pins.Add(VehiclePins);
                    }
                }
                var position = new Position(23.216317, 77.433836);
                map.MoveToRegion(MapSpan.FromCenterAndRadius(position, Distance.FromMeters(5000)));
            }
            catch (Exception ex)
            {

            }
        }

        private void UpdateVehicle_Clicked(object sender, EventArgs e)
        {
            var position = new Position(23.216317, 77.433836);
            map.MoveToRegion(MapSpan.FromCenterAndRadius(position, Distance.FromMeters(5000)));
            Device.StartTimer(TimeSpan.FromSeconds(5), () => TimerStarted());
        }

        private bool TimerStarted()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                Compass.Start(SensorSpeed.UI, applyLowPassFilter: true);
                Compass.ReadingChanged += Compass_ReadingChanged;
                map.Pins.Clear();
                map.Polylines.Clear();
                //Get the car nearby from api but hear we are hardcode the content
                var contents = await mapPageVM.LoadVehicles();
                if (contents != null)
                {
                    foreach (var data in contents)
                    {
                        Pin VehiclePins = new Pin()
                        {
                            Label = "Cars",
                            Type = PinType.Place,
                            Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromBundle("carpinsm.png") : BitmapDescriptorFactory.FromView(new Image() { Source = "carpinsm.png", WidthRequest = 30, HeightRequest = 35 }),
                            //Icon = "carpinsm.png",
                            //   Icon = (Device.RuntimePlatform == Device.Android) ? BitmapDescriptorFactory.FromView("carpinsm.png") : ImageSource.FromFile("Images/waterfront.jpg"),
                            Position = new Position(data.Lattitude, data.Longitude),
                            Rotation = TORotatePoints(headernorthvalue)
                        };
                        map.Pins.Add(VehiclePins);
                    }
                }
            });
            Compass.Stop();
            return true;
        }

        private float TORotatePoints(double headernorthvalue)
        {
            return (float)headernorthvalue;
        }

        double headernorthvalue;
        private void Compass_ReadingChanged(object sender, CompassChangedEventArgs e)
        {
            var data = e.Reading;
            headernorthvalue = data.HeadingMagneticNorth;
        }
    }
}